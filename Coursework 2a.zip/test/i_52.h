#ifndef _I_52_H_
#define _I_52_H_

#include "i_02.h"

#endif /* _I_52_H_ */
